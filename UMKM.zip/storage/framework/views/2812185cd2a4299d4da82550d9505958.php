<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Create Product')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <form action="<?php echo e(route('product.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class=" w-full space-y-6">
                            <div class=" grid grid-cols-3 gap-6">
                                <div class=" flex flex-col gap-2">
                                    <div class=" w-full h-full relative">
                                        <img id="thumbnail" class=" object-cover w-full h-full rounded-md" 
                                            src="<?php echo e(asset('assets/images/placeholder.webp')); ?>" 
                                            alt="Logo">
                                        <div class="w-full text-transparent rounded-md h-full absolute top-0 left-0 flex justify-center items-center hover:bg-black/60 hover:text-white/50 duration-300">
                                            <label for="thumbnail-input" class="relative">
                                                <div class="w-full h-full p-[35%]">
                                                    <svg fill="none" class=" w-full h-full" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M3 17.75A3.25 3.25 0 0 0 6.25 21h4.915l.356-1.423c.162-.648.497-1.24.97-1.712l5.902-5.903a3.279 3.279 0 0 1 2.607-.95V6.25A3.25 3.25 0 0 0 17.75 3H11v4.75A3.25 3.25 0 0 1 7.75 11H3v6.75ZM9.5 3.44 3.44 9.5h4.31A1.75 1.75 0 0 0 9.5 7.75V3.44Zm9.6 9.23-5.903 5.902a2.686 2.686 0 0 0-.706 1.247l-.458 1.831a1.087 1.087 0 0 0 1.319 1.318l1.83-.457a2.685 2.685 0 0 0 1.248-.707l5.902-5.902A2.286 2.286 0 0 0 19.1 12.67Z" fill="currentColor" class="fill-212121"></path></svg>
                                                </div>
                                                <input accept="image/*" type="file" name="thumbnail" class="absolute bottom-0 left-0 z-0 w-40 opacity-0" id="thumbnail-input" required/>
                                            </label>
                                        </div>
                                        <script>
                                            const logoinput = document.getElementById('thumbnail-input');
                                            const logo = document.getElementById('thumbnail');
                    
                                            logoinput.onchange = evt => {
                                                const [file] = logoinput.files;
                                                if (file) {
                                                    logo.src = URL.createObjectURL(file);
                                                }
                                            };
                    
                                            window.addEventListener('paste', e => {
                                                const [file] = e.clipboardData.files;
                                                if (file) {
                                                    logo.src = URL.createObjectURL(file);
                                                }
                                            });
                                        </script>
                                    </div>
                                </div>
                                <div class=" w-full col-span-2 space-y-6">
                                    <div class=" space-y-2">
                                        <label for="name">Product Name</label>
                                        <input class=" w-full border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm" type="text" name="name" id="name">
                                    </div>
                                    <div class=" space-y-2">
                                        <label for="price">Price</label>
                                        <input class=" w-full border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm" type="number" min="0" name="price" id="price">
                                    </div>
                                    <div class=" space-y-2">
                                        <label for="link">Link Youtube</label>
                                        <input class=" w-full border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm" type="text" name="link" id="link">
                                    </div>
                                </div>
                            </div>
                            <div class=" space-y-2">
                                <label for="no_tlp">No. Telephone</label>
                                <input class=" w-full border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm" type="text" name="no_tlp" id="no_tlp">
                            </div>
                            <div class=" space-y-2">
                                <label for="desc">Description</label>
                                <textarea class="w-full border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm" name="description" id="desc" rows="5"></textarea>
                            </div>
                            <div class=" space-y-2">
                                <label for="address">Address</label>
                                <textarea class="w-full border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm" name="address" id="address" rows="5"></textarea>
                            </div>
                            <div x-data="imageGallery" class="flex flex-col gap-2">
                                <label class="font-semibold" for="image_gallery">Gallery</label>
                                <input type="file" class="hidden" id="image_gallery" name="image_gallery[]" multiple @input="previewImages" accept="image/*">
                                
                                <!-- Pratinjau Gambar -->
                                <div class="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                                    <!-- Loop Gambar -->
                                    <template x-for="(image, index) in images" :key="index">
                                        <div class="w-full aspect-[3/2] rounded-md relative overflow-hidden">
                                            <img :src="image" class="w-full h-full object-cover" alt="Gallery Image Preview">
                                            <!-- Tombol Hapus Gambar -->
                                            <button @click="removeImage(index)" class="absolute inset-0 bg-black/50 text-white opacity-0 hover:opacity-100 transition duration-300">
                                                Delete
                                            </button>
                                        </div>
                                    </template>
                            
                                    <!-- Tambahkan Gambar (Placeholder jika kurang dari 8 gambar) -->
                                    <template x-if="images.length < 8">
                                        <label for="image_gallery" class="w-full aspect-[3/2] border border-dashed bg-neutral-100 rounded-md flex items-center justify-center text-gray-500 cursor-pointer hover:bg-neutral-200 transition duration-300">
                                            Input Image
                                        </label>
                                    </template>
                                </div>
                            </div>
                            
                            <script>
                            function imageGallery() {
                                return {
                                    images: [],
                                    
                                    previewImages(event) {
                                        const files = Array.from(event.target.files).slice(0, 8 - this.images.length);
                                        files.forEach(file => {
                                            const url = URL.createObjectURL(file);
                                            this.images.push(url);
                                        });
                                    },
                                    
                                    removeImage(index) {
                                        this.images.splice(index, 1);
                                    }
                                };
                            }
                            </script>
                            
                            <div class="">
                                <button class=" font-bold w-full py-2 bg-indigo-500 hover:bg-indigo-700 duration-300 text-white rounded-md text-center">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\UMKM\resources\views/admin/product/create.blade.php ENDPATH**/ ?>