<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>BizLink</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>

        <!-- Styles -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="antialiased">
        <div class=" bg-neutral-100 min-h-screen">
            <?php if(Route::has('login')): ?>
                <div class=" bg-white/70 backdrop-blur fixed w-full top-0 left-0 p-6 text-right z-10">
                    <div class=" flex justify-center font-black text-4xl">
                        <a href="<?php echo e(route('home')); ?>">BizLink</a>
                    </div>
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('dashboard')); ?>" class=" absolute top-1/2 -translate-y-1/2 right-4 sm:right-10 font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white">Dashboard</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class=" absolute top-1/2 -translate-y-1/2 right-4 sm:right-10 font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white">Log in</a>

                        
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <?php echo e($slot); ?>

        </div>
    </body>

    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
</html>
<?php /**PATH C:\UMKM\resources\views/components/layout/guest.blade.php ENDPATH**/ ?>