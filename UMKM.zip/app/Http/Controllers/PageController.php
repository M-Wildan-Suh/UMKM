<?php

namespace App\Http\Controllers;

use App\Models\NoHandphone;
use App\Models\Product;
use Illuminate\Support\Str;
use Illuminate\Http\Request;

class PageController extends Controller
{
    public function home(Request $request) {
        $no_tlp = NoHandphone::first()->no_tlp;
        if ($request->search != '') {
            $data = Product::where('name', 'like', '%' . $request->search . '%')->inRandomOrder()->get();
        } else {
            $data = Product::inRandomOrder()->get();
        }
        $data = $data->map(function ($item) {
            $item->slug = Str::slug($item->name, '-');
            return $item;
        });
        $recomend = Product::all();
        $recomend = $recomend->map(function ($item) {
            $item->slug = Str::slug($item->name, '-');
            return $item;
        });
        return view('welcome', compact('data', 'no_tlp', 'recomend'));
    }
    public function detail($slug, $id) {
        $no_tlp = NoHandphone::first()->no_tlp;
        $data = Product::find($id);
        parse_str(parse_url($data->youtube, PHP_URL_QUERY), $query);
        $data->embed = isset($query['v']) ? "https://www.youtube.com/embed/" . $query['v'] : $data->youtube;
        return view('detail', compact('data', 'no_tlp'));
    }
}
