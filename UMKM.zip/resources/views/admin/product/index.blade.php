<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Product') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class=" w-full space-y-6">
                        <div class=" flex w-full">
                            <a href="{{route('product.create')}}" class=" font-bold w-full py-2 bg-indigo-500 hover:bg-indigo-700 duration-300 text-white rounded-md text-center">Create Product</a>
                        </div>
                        <div class=" w-full">
                            <div class=" flex flex-col gap-2 font-medium">
                                <form action="{{route('no-handphone.store')}}" method="post">
                                    @csrf
                                    <div class="flex flex-row w-full border border-transparent focus-within:border-indigo-700 focus-within:ring-1 focus-within:ring-indigo-700 rounded-md">
                                        <input type="text" id="no_handphone" name="no_handphone" placeholder="Input Main Phone Number" value="{{$no_tlp}}" class="flex-grow rounded-l-md border border-indigo-500 focus:ring-0 focus:border-none bg-neutral-100">
                                        <button class="py-2 px-3 border border-indigo-500 bg-indigo-500 text-white rounded-r hover:bg-indigo-700 hover:border-indigo-700 duration-300">Change</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class=" w-full">
                            <table class=" w-full rounded-md overflow-hidden">
                                <tr class=" divide-x-2 divide-white bg-indigo-500 text-white h-10">
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Link Youtube</th>
                                    <th>Option</th>
                                </tr>
                                @foreach ($data as $item)
                                    <tr class="odd:bg-neutral-200 even:bg-neutral-100 divide-x-2 divide-white">
                                        <td class=" px-4 py-2 font-bold text-center">{{$item->name}}</td>
                                        <td class=" px-4 py-2">Rp. {{$item->price}}</td>
                                        <td class=" px-4 py-2">{{$item->youtube}}</td>
                                        <td class=" px-4 py-2 flex flex-row justify-center gap-2">
                                            <a href="{{route('product.show', ['product' => $item->id])}}" class=" text-green-500 hover:text-green-800 duration-300">Edit</a>
                                            <form action="{{route('product.destroy', ['product' => $item->id])}}" method="POST">
                                                @csrf
                                                @method('DELETE')
                                                <button class=" text-red-500 hover:text-red-800 duration-300">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
